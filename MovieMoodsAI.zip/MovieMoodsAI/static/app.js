class MovieCurator {
    constructor() {
        this.selectedMovies = [];
        this.searchHistory = this.loadHistory();
        this.initializeElements();
        this.attachEventListeners();
        this.displayHistory();
    }

    initializeElements() {
        this.searchInput = document.getElementById('movieSearch');
        this.searchResults = document.getElementById('searchResults');
        this.movieChips = document.getElementById('movieChips');
        this.selectedMoviesSection = document.getElementById('selectedMovies');
        this.moodSelect = document.getElementById('moodSelect');
        this.recommendBtn = document.getElementById('getRecommendations');
        this.resultsSection = document.getElementById('resultsSection');
        this.recommendations = document.getElementById('recommendations');
        this.historySection = document.getElementById('historySection');
        this.historyList = document.getElementById('historyList');
        this.genreChart = document.getElementById('genreChart');
    }

    attachEventListeners() {
        let searchTimeout;
        this.searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            const query = e.target.value.trim();
            
            if (query.length < 2) {
                this.hideSearchResults();
                return;
            }

            searchTimeout = setTimeout(() => this.searchMovies(query), 300);
        });

        this.recommendBtn.addEventListener('click', () => this.getRecommendations());

        document.addEventListener('click', (e) => {
            if (!this.searchInput.contains(e.target) && !this.searchResults.contains(e.target)) {
                this.hideSearchResults();
            }
        });
    }

    async searchMovies(query) {
        try {
            const response = await fetch(`/api/search?q=${encodeURIComponent(query)}&limit=10`);
            const data = await response.json();
            this.displaySearchResults(data.results);
        } catch (error) {
            console.error('Search error:', error);
        }
    }

    displaySearchResults(results) {
        if (results.length === 0) {
            this.searchResults.innerHTML = '<div style="padding: 15px; color: #999;">No movies found</div>';
            this.searchResults.classList.add('show');
            return;
        }

        this.searchResults.innerHTML = results.map(movie => `
            <div class="search-result-item" data-title="${movie.title}">
                <div class="result-title">${movie.title}</div>
                <div class="result-meta">
                    ${movie.genres.join(', ')} • Rating: ${movie.vote_average}/10
                </div>
            </div>
        `).join('');

        this.searchResults.querySelectorAll('.search-result-item').forEach(item => {
            item.addEventListener('click', () => {
                this.selectMovie(item.dataset.title);
            });
        });

        this.searchResults.classList.add('show');
    }

    hideSearchResults() {
        this.searchResults.classList.remove('show');
    }

    selectMovie(title) {
        if (!this.selectedMovies.includes(title)) {
            this.selectedMovies.push(title);
            this.updateSelectedMovies();
        }
        this.searchInput.value = '';
        this.hideSearchResults();
    }

    updateSelectedMovies() {
        if (this.selectedMovies.length === 0) {
            this.selectedMoviesSection.classList.remove('show');
            return;
        }

        this.selectedMoviesSection.classList.add('show');
        this.movieChips.innerHTML = this.selectedMovies.map(title => `
            <div class="movie-chip">
                <span>${title}</span>
                <span class="chip-remove" data-title="${title}">&times;</span>
            </div>
        `).join('');

        this.movieChips.querySelectorAll('.chip-remove').forEach(btn => {
            btn.addEventListener('click', () => {
                this.removeMovie(btn.dataset.title);
            });
        });
    }

    removeMovie(title) {
        this.selectedMovies = this.selectedMovies.filter(m => m !== title);
        this.updateSelectedMovies();
    }

    async getRecommendations() {
        if (this.selectedMovies.length === 0) {
            alert('Please select at least one movie first!');
            return;
        }

        this.recommendBtn.disabled = true;
        this.recommendBtn.textContent = 'Getting Recommendations...';
        this.recommendations.innerHTML = '<div class="loading">Finding the perfect movies for you...</div>';
        this.resultsSection.classList.add('show');

        try {
            const response = await fetch('/api/recommend', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    movies: this.selectedMovies,
                    mood: this.moodSelect.value,
                    history: this.searchHistory,
                    top_n: 8
                })
            });

            const data = await response.json();
            
            this.selectedMovies.forEach(movie => {
                if (!this.searchHistory.includes(movie)) {
                    this.searchHistory.push(movie);
                }
            });
            
            if (this.searchHistory.length > 10) {
                this.searchHistory = this.searchHistory.slice(-10);
            }
            
            this.saveHistory();
            this.displayRecommendations(data.recommendations);
            this.displayGenreDistribution(data.genre_distribution);
            this.displayHistory();

        } catch (error) {
            console.error('Recommendation error:', error);
            this.recommendations.innerHTML = '<div class="error-message">Failed to get recommendations. Please try again.</div>';
        } finally {
            this.recommendBtn.disabled = false;
            this.recommendBtn.textContent = 'Get Recommendations';
        }
    }

    displayRecommendations(recommendations) {
        if (recommendations.length === 0) {
            this.recommendations.innerHTML = '<div class="error-message">No recommendations found. Try different movies or moods!</div>';
            return;
        }

        this.recommendations.innerHTML = recommendations.map(movie => `
            <div class="movie-card">
                <div class="movie-title">${movie.title}</div>
                <div class="movie-rating">⭐ ${movie.vote_average}/10</div>
                <div class="movie-genres">
                    ${movie.genres.map(g => `<span class="genre-tag">${g}</span>`).join('')}
                </div>
                <div class="movie-overview">${movie.overview}</div>
                <div class="movie-explanation">
                    💡 ${movie.explanation}
                </div>
            </div>
        `).join('');
    }

    displayGenreDistribution(distribution) {
        if (!distribution || Object.keys(distribution).length === 0) {
            return;
        }

        const maxCount = Math.max(...Object.values(distribution));
        const sortedGenres = Object.entries(distribution)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5);

        this.genreChart.innerHTML = '<h4 style="margin-bottom: 15px; color: #333;">Your Top Genres</h4>' +
            sortedGenres.map(([genre, count]) => {
                const percentage = (count / maxCount) * 100;
                return `
                    <div class="genre-bar">
                        <div class="genre-name">
                            <span>${genre}</span>
                            <span>${count} ${count === 1 ? 'movie' : 'movies'}</span>
                        </div>
                        <div class="genre-progress">
                            <div class="genre-fill" style="width: ${percentage}%"></div>
                        </div>
                    </div>
                `;
            }).join('');
        
        this.historySection.classList.add('show');
    }

    displayHistory() {
        if (this.searchHistory.length === 0) {
            this.historyList.innerHTML = '<p style="color: #999;">No search history yet. Start by selecting movies!</p>';
            return;
        }

        this.historyList.innerHTML = '<h4 style="margin-bottom: 15px; color: #333;">Recent Searches</h4>' +
            this.searchHistory.slice(-5).reverse().map((movie, index) => `
                <div class="history-item">${index + 1}. ${movie}</div>
            `).join('');
        
        this.historySection.classList.add('show');
    }

    loadHistory() {
        try {
            const history = localStorage.getItem('movieSearchHistory');
            return history ? JSON.parse(history) : [];
        } catch {
            return [];
        }
    }

    saveHistory() {
        try {
            localStorage.setItem('movieSearchHistory', JSON.stringify(this.searchHistory));
        } catch (error) {
            console.error('Failed to save history:', error);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new MovieCurator();
});
