async function loadFeaturedMovies() {
    try {
        const response = await fetch('/api/movies/featured');
        const data = await response.json();
        
        const carousel = document.getElementById('featuredCarousel');
        carousel.innerHTML = data.movies.map(movie => `
            <a href="/movie/${movie.id}" class="movie-poster-card" style="background-image: url('${movie.poster_path}')">
                <div class="movie-poster-overlay">
                    <div style="font-weight: 700;">${movie.title}</div>
                    <div style="font-size: 0.9rem;">⭐ ${movie.vote_average}</div>
                </div>
            </a>
        `).join('');
        
        if (data.movies.length > 0) {
            const hero = data.movies[0];
            document.getElementById('bannerTitle').textContent = hero.title;
            document.getElementById('bannerOverview').textContent = hero.overview;
            document.getElementById('bannerMeta').innerHTML = `
                <span class="rating">⭐ ${hero.vote_average}</span>
                <span class="separator">•</span>
                <span>${hero.genres.map(g => g.name).join(', ')}</span>
            `;
            document.getElementById('playButton').href = `/movie/${hero.id}`;
            
            const heroBanner = document.getElementById('heroBanner');
            heroBanner.style.backgroundImage = `url('${hero.backdrop_path}')`;
        }
    } catch (error) {
        console.error('Error loading featured movies:', error);
    }
}

async function loadTrendingMovies() {
    try {
        const response = await fetch('/api/movies/trending');
        const data = await response.json();
        
        const carousel = document.getElementById('trendingCarousel');
        carousel.innerHTML = data.movies.map(movie => `
            <a href="/movie/${movie.id}" class="movie-poster-card" style="background-image: url('${movie.poster_path}')">
                <div class="movie-poster-overlay">
                    <div style="font-weight: 700;">${movie.title}</div>
                    <div style="font-size: 0.9rem;">⭐ ${movie.vote_average}</div>
                </div>
            </a>
        `).join('');
    } catch (error) {
        console.error('Error loading trending movies:', error);
    }
}

async function loadRecommendedMovies() {
    try {
        const response = await fetch('/api/movies/featured');
        const data = await response.json();
        
        const carousel = document.getElementById('recommendedCarousel');
        carousel.innerHTML = data.movies.slice(0, 10).map(movie => `
            <a href="/movie/${movie.id}" class="movie-poster-card" style="background-image: url('${movie.poster_path}')">
                <div class="movie-poster-overlay">
                    <div style="font-weight: 700;">${movie.title}</div>
                    <div style="font-size: 0.9rem;">⭐ ${movie.vote_average}</div>
                </div>
            </a>
        `).join('');
    } catch (error) {
        console.error('Error loading recommended movies:', error);
    }
}

async function loadFreeMovieOfWeek() {
    try {
        const response = await fetch('/api/movies/free-of-week');
        const data = await response.json();
        
        if (data.movie) {
            const section = document.getElementById('freeMovieSection');
            section.style.display = 'block';
            document.getElementById('freeMovieTitle').textContent = data.movie.title;
            const endDate = new Date(data.movie.end_date);
            document.getElementById('freeMovieExpiry').textContent = `Available until ${endDate.toLocaleDateString()}`;
            document.getElementById('freeMovieButton').href = `/movie/${data.movie.id}`;
        }
    } catch (error) {
        console.error('Error loading free movie:', error);
    }
}

loadFeaturedMovies();
loadTrendingMovies();
loadRecommendedMovies();
loadFreeMovieOfWeek();
