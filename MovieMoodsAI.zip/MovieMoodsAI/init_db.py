import pandas as pd
import json
import ast
from datetime import datetime, timedelta
import random
from models import db, Movie, FreeMovieOfWeek
from app_streaming import app

def parse_json_field(x):
    try:
        data = ast.literal_eval(x)
        return data if isinstance(data, list) else []
    except:
        return []

def initialize_database():
    print("Initializing database...")
    
    with app.app_context():
        db.drop_all()
        db.create_all()
        
        print("Loading TMDB datasets...")
        movies_df = pd.read_csv('data/tmdb_5000_movies.csv')
        
        print(f"Processing {len(movies_df)} movies...")
        
        movie_objects = []
        for idx, row in movies_df.iterrows():
            try:
                genres = parse_json_field(row['genres'])
                keywords = parse_json_field(row['keywords'])
                
                poster_path = f"/static/posters/movie_{row['id']}.jpg"
                backdrop_path = f"/static/backdrops/movie_{row['id']}.jpg"
                
                is_premium = random.choice([True, True, True, False])
                
                movie = Movie(
                    tmdb_id=int(row['id']),
                    title=row['title'],
                    overview=row['overview'] if pd.notna(row['overview']) else '',
                    genres=genres,
                    keywords=keywords,
                    vote_average=float(row['vote_average']) if pd.notna(row['vote_average']) else 0.0,
                    vote_count=int(row['vote_count']) if pd.notna(row['vote_count']) else 0,
                    release_date=str(row['release_date']) if pd.notna(row['release_date']) else '',
                    poster_path=poster_path,
                    backdrop_path=backdrop_path,
                    runtime=int(row['runtime']) if pd.notna(row['runtime']) else 120,
                    is_premium=is_premium,
                    video_url=f"https://example.com/stream/movie_{row['id']}.mp4"
                )
                movie_objects.append(movie)
                
                if len(movie_objects) >= 100:
                    db.session.bulk_save_objects(movie_objects)
                    db.session.commit()
                    print(f"Saved {idx + 1} movies...")
                    movie_objects = []
                    
            except Exception as e:
                print(f"Error processing movie {idx}: {e}")
                continue
        
        if movie_objects:
            db.session.bulk_save_objects(movie_objects)
            db.session.commit()
        
        print(f"Successfully loaded {len(movies_df)} movies!")
        
        top_movies = Movie.query.order_by(Movie.vote_average.desc()).limit(10).all()
        if top_movies:
            start_date = datetime.utcnow()
            end_date = start_date + timedelta(days=7)
            
            free_movie = FreeMovieOfWeek(
                movie_id=top_movies[0].id,
                start_date=start_date,
                end_date=end_date,
                is_active=True
            )
            db.session.add(free_movie)
            db.session.commit()
            print(f"Set '{top_movies[0].title}' as free movie of the week!")
        
        print("Database initialization complete!")

if __name__ == '__main__':
    initialize_database()
