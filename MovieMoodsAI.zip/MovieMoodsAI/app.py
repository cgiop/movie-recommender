from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from recommendation_engine import MovieRecommendationEngine
import os

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

engine = MovieRecommendationEngine()

@app.route('/')
def index():
    return send_from_directory('templates', 'index.html')

@app.route('/api/search', methods=['GET'])
def search_movies():
    query = request.args.get('q', '')
    limit = int(request.args.get('limit', 10))
    
    results = engine.search_movies(query, limit=limit)
    return jsonify({'results': results})

@app.route('/api/recommend', methods=['POST'])
def get_recommendations():
    data = request.json
    
    movie_titles = data.get('movies', [])
    mood = data.get('mood', 'Any')
    history = data.get('history', [])
    top_n = data.get('top_n', 8)
    
    if history and len(history) > 0:
        movie_titles = list(set(movie_titles + history[-3:]))
    
    recommendations = engine.get_recommendations(
        movie_titles=movie_titles,
        mood=mood,
        history=history,
        top_n=top_n
    )
    
    genre_distribution = {}
    if movie_titles:
        genre_distribution = engine.get_genre_distribution(movie_titles)
    
    return jsonify({
        'recommendations': recommendations,
        'genre_distribution': genre_distribution,
        'mood': mood
    })

@app.route('/api/genre-stats', methods=['POST'])
def get_genre_stats():
    data = request.json
    movie_titles = data.get('movies', [])
    
    distribution = engine.get_genre_distribution(movie_titles)
    
    return jsonify({'distribution': distribution})

@app.route('/api/top-rated', methods=['GET'])
def get_top_rated():
    limit = int(request.args.get('limit', 8))
    top_movies = engine._get_top_rated(limit)
    return jsonify({'movies': top_movies})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
