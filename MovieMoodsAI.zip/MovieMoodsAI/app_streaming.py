from flask import Flask, request, jsonify, render_template, redirect, url_for, flash, session
from flask_cors import CORS
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models import db, User, Movie, WatchHistory, Review, FreeMovieOfWeek
from recommendation_engine import MovieRecommendationEngine
from datetime import datetime, timedelta
import os
from sqlalchemy import func, or_

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'cineby-secret-key-2024')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
CORS(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return render_template('landing.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('browse'))
    
    if request.method == 'POST':
        data = request.json
        email = data.get('email')
        username = data.get('username')
        password = data.get('password')
        
        if User.query.filter_by(email=email).first():
            return jsonify({'success': False, 'message': 'Email already registered'}), 400
        
        if User.query.filter_by(username=username).first():
            return jsonify({'success': False, 'message': 'Username already taken'}), 400
        
        user = User(email=email, username=username)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        login_user(user)
        return jsonify({'success': True, 'message': 'Account created successfully'})
    
    return render_template('auth.html', mode='signup')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('browse'))
    
    if request.method == 'POST':
        data = request.json
        email = data.get('email')
        password = data.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            login_user(user)
            return jsonify({'success': True, 'message': 'Login successful'})
        
        return jsonify({'success': False, 'message': 'Invalid email or password'}), 401
    
    return render_template('auth.html', mode='login')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/browse')
@login_required
def browse():
    return render_template('browse.html')

@app.route('/movie/<int:movie_id>')
@login_required
def movie_detail(movie_id):
    movie = Movie.query.get_or_404(movie_id)
    return render_template('movie_detail.html', movie=movie)

@app.route('/watch/<int:movie_id>')
@login_required
def watch_movie(movie_id):
    movie = Movie.query.get_or_404(movie_id)
    
    free_movie = FreeMovieOfWeek.query.filter(
        FreeMovieOfWeek.movie_id == movie.id,
        FreeMovieOfWeek.is_active == True,
        FreeMovieOfWeek.end_date > datetime.utcnow()
    ).first()
    
    if movie.is_premium and not current_user.is_premium and not free_movie:
        flash('This movie requires a premium subscription')
        return redirect(url_for('movie_detail', movie_id=movie_id))
    
    watch_entry = WatchHistory.query.filter_by(
        user_id=current_user.id,
        movie_id=movie.id
    ).first()
    
    if not watch_entry:
        watch_entry = WatchHistory(user_id=current_user.id, movie_id=movie.id)
        db.session.add(watch_entry)
        db.session.commit()
    
    return render_template('player.html', movie=movie)

@app.route('/profile')
@login_required
def profile():
    return render_template('profile.html')

@app.route('/search')
@login_required
def search_page():
    return render_template('search.html')

@app.route('/api/movies/featured')
def get_featured_movies():
    featured = Movie.query.order_by(Movie.vote_average.desc()).limit(20).all()
    return jsonify({
        'movies': [{
            'id': m.id,
            'title': m.title,
            'overview': m.overview,
            'poster_path': m.poster_path,
            'backdrop_path': m.backdrop_path,
            'vote_average': m.vote_average,
            'genres': m.genres,
            'is_premium': m.is_premium
        } for m in featured]
    })

@app.route('/api/movies/free-of-week')
def get_free_of_week():
    free_movie = FreeMovieOfWeek.query.filter(
        FreeMovieOfWeek.is_active == True,
        FreeMovieOfWeek.end_date > datetime.utcnow()
    ).first()
    
    if not free_movie:
        return jsonify({'movie': None})
    
    movie = Movie.query.get(free_movie.movie_id)
    return jsonify({
        'movie': {
            'id': movie.id,
            'title': movie.title,
            'overview': movie.overview,
            'poster_path': movie.poster_path,
            'backdrop_path': movie.backdrop_path,
            'vote_average': movie.vote_average,
            'genres': movie.genres,
            'end_date': free_movie.end_date.isoformat()
        }
    })

@app.route('/api/movies/trending')
def get_trending():
    trending = Movie.query.order_by(Movie.vote_count.desc()).limit(20).all()
    return jsonify({
        'movies': [{
            'id': m.id,
            'title': m.title,
            'poster_path': m.poster_path,
            'vote_average': m.vote_average,
            'genres': m.genres[:2] if m.genres else []
        } for m in trending]
    })

@app.route('/api/movies/genres/<genre>')
def get_by_genre(genre):
    movies = Movie.query.filter(Movie.genres.contains([{'name': genre}])).limit(20).all()
    return jsonify({
        'movies': [{
            'id': m.id,
            'title': m.title,
            'poster_path': m.poster_path,
            'vote_average': m.vote_average
        } for m in movies]
    })

@app.route('/api/search/movies')
def search_movies():
    query = request.args.get('q', '')
    if not query:
        return jsonify({'results': []})
    
    results = Movie.query.filter(
        or_(
            Movie.title.ilike(f'%{query}%'),
            Movie.overview.ilike(f'%{query}%')
        )
    ).limit(20).all()
    
    return jsonify({
        'results': [{
            'id': m.id,
            'title': m.title,
            'overview': m.overview[:150] + '...' if len(m.overview) > 150 else m.overview,
            'poster_path': m.poster_path,
            'vote_average': m.vote_average,
            'genres': m.genres,
            'is_premium': m.is_premium
        } for m in results]
    })

@app.route('/api/user/watch-history')
@login_required
def get_watch_history():
    history = WatchHistory.query.filter_by(user_id=current_user.id)\
        .order_by(WatchHistory.watched_at.desc()).limit(20).all()
    
    return jsonify({
        'history': [{
            'movie': {
                'id': h.movie.id,
                'title': h.movie.title,
                'poster_path': h.movie.poster_path,
                'vote_average': h.movie.vote_average
            },
            'watched_at': h.watched_at.isoformat(),
            'progress': h.progress,
            'completed': h.completed
        } for h in history]
    })

@app.route('/api/movie/<int:movie_id>/reviews')
def get_movie_reviews(movie_id):
    reviews = Review.query.filter_by(movie_id=movie_id)\
        .order_by(Review.created_at.desc()).all()
    
    return jsonify({
        'reviews': [{
            'id': r.id,
            'username': r.user.username,
            'rating': r.rating,
            'review_text': r.review_text,
            'created_at': r.created_at.isoformat()
        } for r in reviews]
    })

@app.route('/api/movie/<int:movie_id>/review', methods=['POST'])
@login_required
def add_review(movie_id):
    data = request.json
    rating = data.get('rating')
    review_text = data.get('review_text', '')
    
    existing_review = Review.query.filter_by(
        user_id=current_user.id,
        movie_id=movie_id
    ).first()
    
    if existing_review:
        existing_review.rating = rating
        existing_review.review_text = review_text
    else:
        review = Review(
            user_id=current_user.id,
            movie_id=movie_id,
            rating=rating,
            review_text=review_text
        )
        db.session.add(review)
    
    db.session.commit()
    return jsonify({'success': True})

@app.route('/api/user/profile')
@login_required
def get_user_profile():
    watch_count = WatchHistory.query.filter_by(user_id=current_user.id).count()
    review_count = Review.query.filter_by(user_id=current_user.id).count()
    
    return jsonify({
        'user': {
            'username': current_user.username,
            'email': current_user.email,
            'is_premium': current_user.is_premium,
            'created_at': current_user.created_at.isoformat(),
            'stats': {
                'movies_watched': watch_count,
                'reviews_written': review_count
            }
        }
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
