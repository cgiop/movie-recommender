# Personal Movie Curator - AI-Powered Movie Recommendation System

## Overview
An intelligent web application that recommends movies based on user preferences, recent searches, and current mood using content-based filtering with machine learning.

**Live URL**: Accessible via Replit deployment
**Tech Stack**: Flask (Python), Scikit-learn, HTML/CSS/JavaScript
**Dataset**: TMDB 5000 Movie Dataset (50 curated movies)

## Recent Changes
- **2024-11-02**: Initial project setup
  - Created ML-based recommendation engine with CountVectorizer + Cosine Similarity
  - Implemented Flask REST API with /recommend, /search endpoints
  - Built interactive frontend with real-time search and mood selection
  - Added session tracking via LocalStorage
  - Integrated explainable AI reasoning for recommendations

## Project Architecture

### Backend (`app.py`)
- Flask web server on port 5000
- REST API endpoints:
  - `GET /api/search` - Search movies by title
  - `POST /api/recommend` - Get personalized recommendations
  - `POST /api/genre-stats` - Get genre distribution
  - `GET /api/top-rated` - Get top-rated movies

### ML Engine (`recommendation_engine.py`)
- Content-based filtering using scikit-learn
- Features: genres, keywords, movie overview
- Mood-based scoring system (Romantic, Scary, Funny, Intense)
- Similarity calculation using cosine similarity
- Explainable AI with recommendation reasoning

### Frontend
- `templates/index.html` - Main interface
- `static/style.css` - Responsive design with gradient theme
- `static/app.js` - Interactive search, recommendations, history tracking

### Data
- `data/tmdb_5000_movies.csv` - Movie metadata
- `data/tmdb_5000_credits.csv` - Cast and crew information
- `data/create_dataset.py` - Dataset generation script

## Key Features
1. **Session-based Recommendations** - Tracks last 3-5 searches via LocalStorage
2. **Mood-based Filtering** - Dynamic mood selection (Romantic, Scary, Funny, Intense)
3. **Explainable AI** - Shows why each movie was recommended
4. **Real-time Search** - Instant movie search with autocomplete
5. **Genre Visualization** - Shows user's genre preferences

## User Preferences
- Clean, modern UI with gradient purple theme
- Explainable recommendations (transparency over black-box algorithms)
- Privacy-friendly (no login required, local storage only)
- Interactive and educational experience

## Next Phase (Future Enhancements)
- AWS Lambda + API Gateway integration for serverless deployment
- AWS S3 for model file storage and movie posters
- DynamoDB for cross-device persistent user history
- Collaborative filtering to blend content-based and user behavior
- Chart.js integration for advanced visualizations
- Expand dataset to full 5000 movies
