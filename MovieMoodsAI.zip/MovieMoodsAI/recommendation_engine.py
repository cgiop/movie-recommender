import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import json
import ast

class MovieRecommendationEngine:
    def __init__(self, movies_path='data/tmdb_5000_movies.csv', credits_path='data/tmdb_5000_credits.csv'):
        self.movies = pd.read_csv(movies_path)
        self.credits = pd.read_csv(credits_path)
        self.similarity_matrix = None
        self.cv = None
        self.processed_movies = None
        self._prepare_data()
        self._build_model()
        
    def _parse_json_column(self, x):
        try:
            data = ast.literal_eval(x)
            return [item['name'] for item in data] if isinstance(data, list) else []
        except:
            return []
    
    def _prepare_data(self):
        df = self.movies.copy()
        
        df['genres'] = df['genres'].apply(self._parse_json_column)
        df['keywords'] = df['keywords'].apply(self._parse_json_column)
        
        df['genre_str'] = df['genres'].apply(lambda x: ' '.join(x).lower())
        df['keyword_str'] = df['keywords'].apply(lambda x: ' '.join(x).lower())
        df['overview'] = df['overview'].fillna('').str.lower()
        
        df['combined_features'] = (
            df['genre_str'] + ' ' + 
            df['keyword_str'] + ' ' + 
            df['overview']
        )
        
        self.processed_movies = df
    
    def _build_model(self):
        self.cv = CountVectorizer(max_features=5000, stop_words='english')
        vectors = self.cv.fit_transform(self.processed_movies['combined_features']).toarray()
        self.similarity_matrix = cosine_similarity(vectors)
    
    def _get_mood_keywords(self, mood):
        mood_map = {
            'Romantic': ['love', 'romance', 'romantic', 'relationship', 'couple', 'marriage', 'wedding'],
            'Scary': ['horror', 'scary', 'fear', 'terror', 'ghost', 'haunted', 'demon', 'monster', 'creature', 'supernatural'],
            'Funny': ['comedy', 'funny', 'humor', 'laugh', 'hilarious', 'party', 'bachelor'],
            'Intense': ['thriller', 'suspense', 'intense', 'action', 'crime', 'war', 'battle', 'fight', 'chase', 'revenge']
        }
        return mood_map.get(mood, [])
    
    def _calculate_mood_score(self, movie_idx, mood):
        if not mood or mood == 'Any':
            return 1.0
        
        mood_keywords = self._get_mood_keywords(mood)
        if not mood_keywords:
            return 1.0
        
        movie = self.processed_movies.iloc[movie_idx]
        combined_text = movie['combined_features'].lower()
        
        score = sum(1 for keyword in mood_keywords if keyword in combined_text)
        return max(0.1, min(1.0, score / len(mood_keywords) * 2))
    
    def get_recommendations(self, movie_titles, mood='Any', history=None, top_n=8):
        if not movie_titles:
            return self._get_top_rated(top_n)
        
        if isinstance(movie_titles, str):
            movie_titles = [movie_titles]
        
        all_similarity_scores = np.zeros(len(self.processed_movies))
        found_movies = []
        
        for movie_title in movie_titles:
            movie_idx = self._find_movie_index(movie_title)
            if movie_idx is not None:
                found_movies.append(movie_idx)
                similarity_scores = self.similarity_matrix[movie_idx]
                mood_scores = np.array([self._calculate_mood_score(i, mood) for i in range(len(self.processed_movies))])
                combined_scores = similarity_scores * mood_scores
                all_similarity_scores += combined_scores
        
        if not found_movies:
            return []
        
        all_similarity_scores = all_similarity_scores / len(found_movies)
        
        for idx in found_movies:
            all_similarity_scores[idx] = -1
        
        similar_indices = all_similarity_scores.argsort()[::-1][:top_n]
        
        recommendations = []
        for idx in similar_indices:
            if all_similarity_scores[idx] > 0:
                movie = self.processed_movies.iloc[idx]
                
                explanation_parts = []
                for ref_idx in found_movies:
                    ref_movie = self.processed_movies.iloc[ref_idx]
                    common_genres = set(movie['genres']) & set(ref_movie['genres'])
                    if common_genres:
                        explanation_parts.append(f"shares genres with '{ref_movie['title']}': {', '.join(common_genres)}")
                
                if mood and mood != 'Any':
                    mood_keywords = self._get_mood_keywords(mood)
                    movie_text = movie['combined_features'].lower()
                    matched_moods = [kw for kw in mood_keywords if kw in movie_text]
                    if matched_moods:
                        explanation_parts.append(f"matches your {mood.lower()} mood")
                
                explanation = "Because you liked " + ", ".join([self.processed_movies.iloc[i]['title'] for i in found_movies[:2]])
                if explanation_parts:
                    explanation += " — " + "; ".join(explanation_parts[:2])
                
                recommendations.append({
                    'id': int(movie['id']),
                    'title': movie['title'],
                    'genres': movie['genres'],
                    'overview': movie['overview'],
                    'vote_average': float(movie['vote_average']),
                    'release_date': movie['release_date'],
                    'explanation': explanation,
                    'similarity_score': float(all_similarity_scores[idx])
                })
        
        return recommendations
    
    def _find_movie_index(self, movie_title):
        movie_title = movie_title.lower().strip()
        
        exact_match = self.processed_movies[self.processed_movies['title'].str.lower() == movie_title]
        if not exact_match.empty:
            return exact_match.index[0]
        
        partial_match = self.processed_movies[self.processed_movies['title'].str.lower().str.contains(movie_title, na=False)]
        if not partial_match.empty:
            return partial_match.index[0]
        
        return None
    
    def search_movies(self, query, limit=10):
        query = query.lower().strip()
        if not query:
            return []
        
        matches = self.processed_movies[
            self.processed_movies['title'].str.lower().str.contains(query, na=False)
        ].head(limit)
        
        results = []
        for _, movie in matches.iterrows():
            results.append({
                'id': int(movie['id']),
                'title': movie['title'],
                'genres': movie['genres'],
                'overview': movie['overview'][:150] + '...' if len(movie['overview']) > 150 else movie['overview'],
                'vote_average': float(movie['vote_average']),
                'release_date': movie['release_date']
            })
        
        return results
    
    def _get_top_rated(self, top_n=8):
        top_movies = self.processed_movies.nlargest(top_n, 'vote_average')
        
        results = []
        for _, movie in top_movies.iterrows():
            results.append({
                'id': int(movie['id']),
                'title': movie['title'],
                'genres': movie['genres'],
                'overview': movie['overview'],
                'vote_average': float(movie['vote_average']),
                'release_date': movie['release_date'],
                'explanation': 'Highly rated movie you might enjoy',
                'similarity_score': float(movie['vote_average']) / 10.0
            })
        
        return results
    
    def get_genre_distribution(self, movie_titles):
        genre_count = {}
        for title in movie_titles:
            idx = self._find_movie_index(title)
            if idx is not None:
                movie = self.processed_movies.iloc[idx]
                for genre in movie['genres']:
                    genre_count[genre] = genre_count.get(genre, 0) + 1
        
        return genre_count

if __name__ == '__main__':
    engine = MovieRecommendationEngine()
    
    print("Testing recommendation engine...")
    print("\n1. Search for 'inception':")
    results = engine.search_movies('inception')
    for r in results:
        print(f"  - {r['title']} ({r['release_date'][:4]})")
    
    print("\n2. Get recommendations based on 'Inception' with 'Intense' mood:")
    recommendations = engine.get_recommendations(['Inception'], mood='Intense', top_n=5)
    for rec in recommendations:
        print(f"\n  {rec['title']} (Rating: {rec['vote_average']})")
        print(f"  Genres: {', '.join(rec['genres'])}")
        print(f"  {rec['explanation']}")
    
    print("\n3. Test genre distribution:")
    distribution = engine.get_genre_distribution(['Inception', 'The Matrix', 'Interstellar'])
    print(f"  {distribution}")
